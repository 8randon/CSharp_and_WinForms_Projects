﻿// Brandon Townsend

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;


namespace CptS321
{

	public class Spreadsheet
	{
		//custon derived class for Spreadsheet
		private class SCell : Cell
		{
			SCell()
			{
				RowIndex = 26;
				ColumnIndex = 26;
			}

			public SCell(int RowInd, int ColumnInd)
			{
				RowIndex = RowInd;
				ColumnIndex = ColumnInd;
			}
			//adding functionality to Value so only Spreadsheet can access it
			private string Value { get; set; }
		}

		SCell[,] SpreadS;

		private readonly int nRows;
		public int RowCount
		{
			get { return nRows; }
		}

		private readonly int nColumns;
		public int ColumnCount
		{
			get { return nColumns; }
		}

		public event PropertyChangedEventHandler CellPropertyChanged;

		//Defining Response behaviour to CellPropertyChanged event
		private void OnCellPropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			string temp = "";

			SCell target = (SCell)sender;

			//if the target text has been set before and starts with '='...
			if (target.Text != null && target.Text[0] == '=')
			{
				//do math

				//~*~* MaTh *~*~

				//but for now:
				//just grab the rest of the string...
				for (int i = 1; i < target.Text.Length; i++)
				{
					temp += target.Text[i].ToString();
				}
				//... and set the target cell's value to it
				target.Value = temp;
			}
			//...otherwise just set the target cell's value to it
			else
			{
				target.Value=target.Text;
			}

			// finally, fire off CellPropertyChanged event
			CellPropertyChanged?.Invoke(target, e);
		}

		Spreadsheet()
		{
			SpreadS = new SCell[26, 50];
		}

		public Spreadsheet(int Rows, int Columns)
		{
			SpreadS = new SCell[Rows, Columns];
			nRows = Rows;
			nColumns = Columns;
			
			//initialize and populate cells
			for (int i = 0; i < Rows; i++)
			{
				for (int j = 0; j < Columns; j++)
				{
					SpreadS[i, j] = new SCell(i, j) { Text = i.ToString() + " " + j.ToString() };

					//if PropertyChanged event is fired for this cell, call OnCellPropertyChanged is called
					//"Subscribing" to this cell's PropertyChanged event
					SpreadS[i, j].PropertyChanged += this.OnCellPropertyChanged;
				}
			}
		}

		//get that cell!
		public Cell GetCell(int row, int column)
		{
			if (row > nRows || column > nColumns)
			{
				return null;
			}
			else
			{
				return SpreadS[row, column];
			}
		}

		//demo function
		public void Demo()
		{
			int[,] randoms = new int[50,2];
			int tempi = 0;
			int tempj = 0;

			Random rand = new Random();

			for (int i = 0; i < 50; i++)
			{
				//generate random numbers
				tempi = rand.Next(RowCount);
				tempj = rand.Next(ColumnCount);

				//check list to see if these coordinates have already been generated
				for (int j = 0; j < i; j++)
				{
					//if they have, generate more and start the check progress over
					if (randoms[j, 0] == tempi && randoms[j,1] == tempj)
					{
						tempi = rand.Next(RowCount);
						tempj = rand.Next(ColumnCount);
						j = 0;
					}
				}

				//put the coordinates into the list
				randoms[i, 0] = tempi;
				randoms[i, 1] = tempj;

				//set text of the cell at the coordinates
				SpreadS[tempi, tempj].Text = "Hullabaloo";
				
			}

			//demonstrating the '=' handling works
			for (int i = 0; i < RowCount; i++)
			{
				SpreadS[i, 1].Text = "This is cell B" + i.ToString();
				SpreadS[i, 0].Text = "=" + SpreadS[i, 1].Text;
			}

		}
		
	}

	

	public abstract class Cell : INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		public int RowIndex { get; internal set; }
		public int ColumnIndex { get; internal set; }

	
		protected string text { get; set; }
		//text property; handling new text being set
		public string Text
		{
			get
			{
				return text;
			}
			set
			{
				//only change the value if it's new
				if (!Equals(value, text))
				{
					text = value;
					//trigger event protocol!
					OnPropertyChanged("Text");
				}
			}
		}

		protected void OnPropertyChanged(string texT)
		{
			//using delegate stuff apparently? cool but need to research more...
			//fire off that event!
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(texT));
		}
	
		protected string value;
		public string Value;
		

	}
}