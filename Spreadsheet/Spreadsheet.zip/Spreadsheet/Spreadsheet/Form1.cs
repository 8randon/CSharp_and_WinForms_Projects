﻿//Brandon Townsend

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spreadsheet
{
	public partial class Form1 : Form
	{
		CptS321.Spreadsheet Sheet;
		public Form1()
		{
			//setting satagrid properties
			InitializeComponent();
			dataGridView1.ColumnCount = 26;
			dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;

			dataGridView1.RowCount = 50;
			dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;

			// default header style for now

			//generate column names
			for (int i = 0; i < dataGridView1.ColumnCount; i++)
			{
				dataGridView1.Columns[i].Name = Convert.ToChar(65 + i).ToString();
			}

			//generate row headers
			for (int i = 1; i <= dataGridView1.RowCount; i++)
			{
				dataGridView1.Rows[i - 1].HeaderCell.Value = (i).ToString();
			}

			Sheet = new CptS321.Spreadsheet(dataGridView1.RowCount, dataGridView1.ColumnCount);

			//if CellPropertyChanged event is fired, UpdateCell is called
			//"Subscribing" to this Spreadsheet's CellPropertyChanged event
			Sheet.CellPropertyChanged += UpdateCell;

		}

		public void UpdateCell(object sender, PropertyChangedEventArgs e)
		{
			CptS321.Cell target = (CptS321.Cell)sender;

			//updates GUI cell with value of corresponding Spreadsheet cell
			dataGridView1.Rows[target.RowIndex].Cells[target.ColumnIndex].Value = target.Value;

		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			//lord knows i tried to get this to work so everything is in the constructor for now
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// demo demo who wants a demo
			Sheet.Demo();
		}
	}
}
